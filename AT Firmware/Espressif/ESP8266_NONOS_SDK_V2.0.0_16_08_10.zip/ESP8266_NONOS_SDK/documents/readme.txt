SDK Development Guide @ http://bbs.espressif.com/viewtopic.php?f=51&t=1023
All documentations @ http://bbs.espressif.com/viewforum.php?f=51
